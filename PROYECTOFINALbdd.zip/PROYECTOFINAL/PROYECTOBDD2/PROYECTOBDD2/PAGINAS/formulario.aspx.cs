﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace PROYECTOBDD2.PAGINAS
{


    public partial class formulario : System.Web.UI.Page
    {
        int iddivorciado = 0;
        int iddivorciada = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            ID_FORMULARIO();
            txtidformulario.Enabled = false;
        }
        //BOTON GUARDAR
        protected void btnGuardar_Click(object sender, EventArgs e)
        {

            INSERTAR_DATOS_DIVORCIO();
            INSERTAR_NACIONALIDAD_DIVORCIADO();
            INSERTAR_NIVEL_INSTRUCCION_DIVORCIADO();
            INSERTAR_ETNIA_DIVORCIADO();
            INSERTAR_UBICACION_DIVORCIADO();
            INSERTAR_DATOS_PERSONALES_DIVORCIADO1();
            //Response.Write(ID_DIVORCIADO());
            iddivorciado = ID_DIVORCIADO();
            INSERTAR_NACIONALIDAD_DIVORCIADA();
            INSERTAR_NIVEL_INSTRUCCION_DIVORCIADA();
            INSERTAR_ETNIA_DIVORCIADA();
            INSERTAR_UBICACION_DIVORCIADA();
            INSERTAR_DATOS_PERSONALES_DIVORCIADA1();
            Response.Write(ID_DIVORCIADA());
            iddivorciada = ID_DIVORCIADA();
            //Response.Write(ID_DATOS_DIVORCIO());

            INSERTAR_DATOS_UBICACION_FORMULARIO();
            INSERTAR_FORMULARIO();
            limpiarCampos();
        }

        public void limpiarCampos()
        {
            txtOficina.Text = "";
            txtprovincia.Text = "";
            txtcanton.Text = "";
            txtparroquiaform.Text = "";
            txtfechaincripcion.Text = "";
            txtUSONEC.Text = "";
            txtnumerooficina.Text = "";
            txtprovincia.Text = "";
            txtusonecfechacritica.Text = "";
            txtactainscripcion.Text = "";
            txtfechasentencia.Text = "";
            txtfechamatrimonio.Text = "";
            txtduracionmatrimonio.Text = "";
            txtnombredivorciado.Text = "";
            txtnombredivorciada.Text = "";
            txtapellidodivorciado.Text = "";
            txtapellidodivorciada.Text = "";
            txtcedulapasaportedivorciado.Text = "";
            txtcedulapasaportedivorciada.Text = "";
            txtfechanacimientodivorciado.Text = "";
            txtfechanacimientodivorciada.Text = "";
            txtedaddivorciado.Text = "";
            txtedaddivorciada.Text = "";
            txtnumerodehijosdivorciado.Text = "";
            txtnumerodehijosdivorciada.Text = "";
            txtprovinciadivorciado.Text = "";
            txtprovinciadivorciada.Text = "";
            txtcantondivorciado.Text = "";
            txtcantondivorciada.Text = "";
            txtparroquiadivorciado.Text = "";
            txtparroquiadivorciada.Text = "";
            txtlocalidaddivorciado.Text = "";
            txtlocalidaddivorciada.Text = "";
            txtlocalidaddivorciadausoinec.Text = "";
            txtDPAdivorciado.Text = "";
            txtDPAdivorciada.Text = "";
            txtnecpiedepagina.Text = "";
            txtobservaciones.Text = "";
            txtlocalidaddivorciadousoinec.Text = "";
        }

        public void INSERTAR_FORMULARIO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_FORMULARIO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                /* insertar formulario  */
                cmd.Parameters.Add("@id_matri", SqlDbType.Int).Value = ID_DATOS_DIVORCIO();
                cmd.Parameters.Add("@id_ubi", SqlDbType.Int).Value = ID_UBICACION_FORMULARIO();
                cmd.Parameters.Add("@iddaro_per", SqlDbType.Int).Value = iddivorciado;
                cmd.Parameters.Add("@iddaro_per1", SqlDbType.Int).Value = iddivorciada;
                cmd.Parameters.Add("@oficina_form", SqlDbType.VarChar).Value = txtOficina.Text;
                cmd.Parameters.Add("@fecha_inscrp", SqlDbType.Date).Value = Convert.ToDateTime(txtfechaincripcion.Text);
                cmd.Parameters.Add("@nec_form", SqlDbType.VarChar).Value = txtUSONEC.Text;
                cmd.Parameters.Add("@num_ofic_form", SqlDbType.Int).Value = txtnumerooficina.Text;
                cmd.Parameters.Add("@act_inscip_form", SqlDbType.VarChar).Value = txtactainscripcion.Text;
                cmd.Parameters.Add("@fecha_sent_form", SqlDbType.Date).Value = txtfechasentencia.Text;
                cmd.Parameters.Add("@nombre_func_form", SqlDbType.VarChar).Value = txtfucnionarioresponsabel.Text;
                cmd.Parameters.Add("@cedula_func_form", SqlDbType.VarChar).Value = txtcedulafuncionario.Text;
                cmd.Parameters.Add("@obser_form", SqlDbType.VarChar).Value = txtobservaciones.Text;
                cmd.Parameters.Add("@cod_crit_codi", SqlDbType.VarChar).Value = txtnecpiedepagina.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();

            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);

            }

        }

        //OBTENER ULTIMO ID DEL FORMULARIO
        public void ID_FORMULARIO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int id_formulario = 0;
            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 ID_FORM FROM FORMULARIO ORDER BY ID_FORM DESC", con);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            SqlDataReader leer;
            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                id_formulario = Convert.ToInt32(leer["ID_FORM"]) + 1;
                txtidformulario.Text = id_formulario.ToString();
            }
            con.Close();
        }

        //OBTENER ULTIMO ID DE LA TABLA UBICACION
        public int ID_UBICACION_FORMULARIO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int id_ubi = 0;
            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 id_ubi FROM UBICACION ORDER BY id_ubi DESC", con);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            SqlDataReader leer;
            con.Open();
            leer = cmd.ExecuteReader();
            if (leer.Read() == true)
            {
                id_ubi = Convert.ToInt32(leer["id_ubi"]);
                return id_ubi;
            }
            con.Close();
            return id_ubi;
        }

        public void INSERTAR_DATOS_UBICACION_FORMULARIO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_UBICACION_FORMULARIO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                cmd.Parameters.Add("@Provincia", SqlDbType.VarChar).Value = txtprovincia.Text;
                cmd.Parameters.Add("@Canton", SqlDbType.VarChar).Value = txtcanton.Text;
                cmd.Parameters.Add("@Parroquia", SqlDbType.VarChar).Value = txtparroquiaform.Text;
                cmd.Parameters.Add("@Localidad", SqlDbType.VarChar).Value = "null";
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }
        }

        //OBTENER ULTIMO ID DE LA TABLA DATOS_DIVORCIO
        public int ID_DATOS_DIVORCIO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int idmatri = 0;
            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 ID_MATRI FROM DATOS_DIVORCIO ORDER BY ID_MATRI DESC", con);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            SqlDataReader leer;
            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                idmatri = Convert.ToInt32(leer["ID_MATRI"]);
                return idmatri;
            }
            con.Close();
            return idmatri;
        }

        //OBTENER ULTIMO ID DE LA DIVORCIADA
        public int ID_DIVORCIADA()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int iddato_per = 0;
            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 IDDARO_PER FROM DATOS_PERSONALES ORDER BY IDDARO_PER DESC", con);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            SqlDataReader leer;
            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                iddato_per = Convert.ToInt32(leer["IDDARO_PER"]);
                return iddato_per;

            }
            con.Close();
            return iddato_per;
        }

        //OBTENER ULTIMO ID DE LA DIVORCIADO
        public int ID_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int iddato_per = 0;
            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 IDDARO_PER FROM DATOS_PERSONALES ORDER BY IDDARO_PER DESC", con);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            SqlDataReader leer;
            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                iddato_per = Convert.ToInt32(leer["IDDARO_PER"]);
                return iddato_per;

            }
            con.Close();
            return iddato_per;
        }



        //AQUI
        public void INSERTAR_DATOS_PERSONALES_DIVORCIADA1()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_DATOS_PERSONALES_DIVORCIADA", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                //Response.Write("Entra");
                //insertar datos personales del divorciado 
                cmd.Parameters.Add("@id_ubi", SqlDbType.Int).Value = ID_UBICACION_DIVORCIADO();
                cmd.Parameters.Add("@id_autoID", SqlDbType.Int).Value = ID_AUTOIDENTIFICACION_DIVORCIADO();
                cmd.Parameters.Add("@id_inst", SqlDbType.Int).Value = ID_NIVEL_INSTRUCCION_DIVORCIADO();
                cmd.Parameters.Add("@id_nac", SqlDbType.Int).Value = ID_NACIONALIDAD_DIVORCIADO();
                cmd.Parameters.Add("@nombre_per", SqlDbType.VarChar).Value = txtnombredivorciada.Text;
                cmd.Parameters.Add("@apellido", SqlDbType.VarChar).Value = txtapellidodivorciada.Text;
                cmd.Parameters.Add("@cedula", SqlDbType.VarChar).Value = txtcedulapasaportedivorciada.Text;
                cmd.Parameters.Add("@fecha", SqlDbType.Date).Value = Convert.ToDateTime(txtfechanacimientodivorciada.Text);
                cmd.Parameters.Add("@edad", SqlDbType.Int).Value = Convert.ToInt32(txtedaddivorciada.Text);
                cmd.Parameters.Add("@hijos", SqlDbType.Int).Value = Convert.ToInt32(txtnumerodehijosdivorciada.Text);
                cmd.Parameters.Add("@genero", SqlDbType.VarChar).Value = "FEMENINO";
                cmd.Parameters.Add("@DPA_PER", SqlDbType.Int).Value = Convert.ToInt32(txtlocalidaddivorciadausoinec.Text); ;
                cmd.Parameters.Add("@LOCAL_PER", SqlDbType.Int).Value = Convert.ToInt32(txtDPAdivorciada.Text); ;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();

            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }
        }

        public void INSERTAR_DATOS_PERSONALES_DIVORCIADO1()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_DATOS_PERSONALES_DIVORCIADO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                //Response.Write("Entra");
                //insertar datos personales del divorciado 
                cmd.Parameters.Add("@id_ubi", SqlDbType.Int).Value = ID_UBICACION_DIVORCIADO();
                cmd.Parameters.Add("@id_autoID", SqlDbType.Int).Value = ID_AUTOIDENTIFICACION_DIVORCIADO();
                cmd.Parameters.Add("@id_inst", SqlDbType.Int).Value = ID_NIVEL_INSTRUCCION_DIVORCIADO();
                cmd.Parameters.Add("@id_nac", SqlDbType.Int).Value = ID_NACIONALIDAD_DIVORCIADO();
                cmd.Parameters.Add("@nombre_per", SqlDbType.VarChar).Value = txtnombredivorciado.Text;
                cmd.Parameters.Add("@apellido", SqlDbType.VarChar).Value = txtapellidodivorciado.Text;
                cmd.Parameters.Add("@cedula", SqlDbType.VarChar).Value = txtcedulapasaportedivorciado.Text;
                cmd.Parameters.Add("@fecha", SqlDbType.Date).Value = Convert.ToDateTime(txtfechanacimientodivorciado.Text);
                cmd.Parameters.Add("@edad", SqlDbType.Int).Value = Convert.ToInt32(txtedaddivorciado.Text);
                cmd.Parameters.Add("@hijos", SqlDbType.Int).Value = Convert.ToInt32(txtnumerodehijosdivorciado.Text);
                cmd.Parameters.Add("@genero", SqlDbType.VarChar).Value = "Masculino";
                cmd.Parameters.Add("@DPA_PER", SqlDbType.Int).Value = Convert.ToInt32(txtlocalidaddivorciadousoinec.Text); ;
                cmd.Parameters.Add("@LOCAL_PER", SqlDbType.Int).Value = Convert.ToInt32(txtDPAdivorciado.Text); ;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();

            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }
        }

        public int ID_UBICACION_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int id_ubi = 0;

            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 id_ubi FROM UBICACION ORDER BY id_ubi DESC", con);

            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;

            SqlDataReader leer;

            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                id_ubi = Convert.ToInt32(leer["id_ubi"]);
                return id_ubi;

            }
            con.Close();
            return id_ubi;

        }

        public int ID_AUTOIDENTIFICACION_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int id_autoID = 0;

            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 ID_AUTOID FROM AUTOIDENTIFICACION ORDER BY ID_AUTOID DESC", con);

            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;

            SqlDataReader leer;

            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                id_autoID = Convert.ToInt32(leer["ID_AUTOID"]);
                return id_autoID;

            }
            con.Close();
            return id_autoID;

        }

        public int ID_NIVEL_INSTRUCCION_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int id_nivel = 0;

            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 ID_INST FROM NIVEL_INSTRUCCION ORDER BY ID_INST DESC", con);

            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;

            SqlDataReader leer;

            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                id_nivel = Convert.ToInt32(leer["ID_INST"]);
                return id_nivel;

            }
            con.Close();
            return id_nivel;

        }

        public int ID_NACIONALIDAD_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            int id_nacion = 0;

            SqlCommand cmd = new SqlCommand("SELECT  TOP 1 ID_NAC FROM NACIONALIDAD ORDER BY ID_NAC DESC", con);

            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;

            SqlDataReader leer;

            con.Open();
            leer = cmd.ExecuteReader();

            if (leer.Read() == true)
            {
                id_nacion = Convert.ToInt32(leer["ID_NAC"]);
                return id_nacion;

            }
            con.Close();
            return id_nacion;

        }



        public void INSERTAR_UBICACION_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_UBICACION_DIVORCIADO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                /* insertar causa del divorcio */
                cmd.Parameters.Add("@Provincia", SqlDbType.VarChar).Value = txtprovinciadivorciado.Text;
                cmd.Parameters.Add("@Canton", SqlDbType.VarChar).Value = txtcantondivorciado.Text;
                cmd.Parameters.Add("@Parroquia", SqlDbType.VarChar).Value = txtparroquiadivorciado.Text;
                cmd.Parameters.Add("@Localidad", SqlDbType.VarChar).Value = txtlocalidaddivorciado.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }
        }


        public void INSERTAR_UBICACION_DIVORCIADA()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_UBICACION_DIVORCIADA", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                /* insertar causa del divorcio */
                cmd.Parameters.Add("@Provincia", SqlDbType.VarChar).Value = txtprovinciadivorciada.Text;
                cmd.Parameters.Add("@Canton", SqlDbType.VarChar).Value = txtcantondivorciada.Text;
                cmd.Parameters.Add("@Parroquia", SqlDbType.VarChar).Value = txtparroquiadivorciada.Text;
                cmd.Parameters.Add("@Localidad", SqlDbType.VarChar).Value = txtlocalidaddivorciada.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }
        }


        public void INSERTAR_ETNIA_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_ETNIA_DIVORCIADO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                cmd.Parameters.Add("@etnia", SqlDbType.VarChar).Value = cmbidentificacionetnicadivorciado.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }


        }

        public void INSERTAR_ETNIA_DIVORCIADA()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True"); 
            SqlCommand cmd = new SqlCommand("INSERTAR_ETNIA_DIVORCIADA", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                cmd.Parameters.Add("@etnia", SqlDbType.VarChar).Value = cmbidentificacionetnicadivorciada.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }


        }

        public void INSERTAR_NIVEL_INSTRUCCION_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_NIVEL_INSTRUCCION_DIVORCIADO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                cmd.Parameters.Add("@leer_esc", SqlDbType.VarChar).Value = cmbleerescribirdivorciado.Text;
                cmd.Parameters.Add("@nivel", SqlDbType.VarChar).Value = cmbnivelinstrucciondivorciado.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }

        }

        public void INSERTAR_NIVEL_INSTRUCCION_DIVORCIADA()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_NIVEL_INSTRUCCION_DIVORCIADA", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                cmd.Parameters.Add("@leer_esc", SqlDbType.VarChar).Value = cmbleerescribirdivorciada.Text;
                cmd.Parameters.Add("@nivel", SqlDbType.VarChar).Value = cmbnivelinstrucciondivorciada.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }

        }
        public void INSERTAR_NACIONALIDAD_DIVORCIADO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_NACIONALIDAD_DIVORCIADO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                /* insertar nacionalidad del divorciado */
                cmd.Parameters.Add("@Nacion", SqlDbType.VarChar).Value = cmbNacionalidadDivorciado.Text;
                cmd.Parameters.Add("@Pais_nac", SqlDbType.VarChar).Value = txtnombrepais.Text;
                cmd.Parameters.Add("@codpaid_nac", SqlDbType.BigInt).Value = Convert.ToInt64(txtcodigopais.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }

        }

        public void INSERTAR_NACIONALIDAD_DIVORCIADA()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_NACIONALIDAD_DIVORCIADA", con);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                /* insertar nacionalidad del divorciado */
                cmd.Parameters.Add("@Nacion", SqlDbType.VarChar).Value = cmbNacionalidadDivorciada.Text;
                cmd.Parameters.Add("@Pais_nac", SqlDbType.VarChar).Value = txtnombrepaisdivorciada.Text;
                cmd.Parameters.Add("@codpaid_nac", SqlDbType.BigInt).Value = Convert.ToInt64(txtcodigopaisdivorciada.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }

        }


        public void INSERTAR_DATOS_DIVORCIO()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("INSERTAR_DATO_DIVORCIO", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                /* insertar datos del divorcio */
                cmd.Parameters.Add("@FechaMatri", SqlDbType.Date).Value = Convert.ToDateTime(txtfechamatrimonio.Text);
                cmd.Parameters.Add("@bienes", SqlDbType.VarChar).Value = cmbCapitulacionBienes.Text;
                cmd.Parameters.Add("@Duracion_Matri", SqlDbType.Int).Value = Int32.Parse(txtduracionmatrimonio.Text);
                cmd.Parameters.Add("@causa", SqlDbType.VarChar).Value = cmbCausaDivorcio.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Registro realizado exitosamente')</script>");
                con.Close();
            }

            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Algún campo se encuentra vacio')</script>" + ex);
            }
        }

        protected void cmbNacionalidadDivorciado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNacionalidadDivorciado.Text.Equals("Ecuatoriano"))
            {
                txtnombrepais.Enabled = false;
                txtcodigopais.Enabled = false;
                txtnombrepais.Text = "Ecuador";
                txtcodigopais.Text = "593";
            }
            else
            {
                txtnombrepais.Enabled = true;
                txtcodigopais.Enabled = true;
                txtnombrepais.Text = "";
                txtcodigopais.Text = "";
            }

        }

        protected void cmbNacionalidadDivorciada_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNacionalidadDivorciada.Text.Equals("Ecuatoriano"))
            {
                txtnombrepaisdivorciada.Enabled = false;
                txtcodigopaisdivorciada.Enabled = false;
                txtnombrepaisdivorciada.Text = "Ecuador";
                txtcodigopaisdivorciada.Text = "593";
            }
            else
            {
                txtnombrepaisdivorciada.Enabled = true;
                txtcodigopaisdivorciada.Enabled = true;
                txtnombrepaisdivorciada.Text = "";
                txtcodigopaisdivorciada.Text = "";
            }
        }
    }
}