﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace PROYECTOBDD2.PAGINAS
{
    public partial class datos : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnbuscar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select ID_FORM AS 'FORMULARIO N°', UBICACION.PROVINCIA, UBICACION.CANTON, AUTOIDENTIFICACION.ETNIA, NACIONALIDAD.NACION, NOMBRE_PER AS 'NOMBRE', APELLIDO_PER AS 'APELLIDO',EDAD , CAUSA from FORMULARIO inner join DATOS_PERSONALES on DATOS_PERSONALES.IDDARO_PER = FORMULARIO.IDDARO_PER inner join UBICACION on UBICACION.ID_UBI = DATOS_PERSONALES.ID_UBI inner join AUTOIDENTIFICACION on AUTOIDENTIFICACION.ID_AUTOID = DATOS_PERSONALES.ID_AUTOID inner join NACIONALIDAD on NACIONALIDAD.ID_NAC = DATOS_PERSONALES.ID_NAC inner join DATOS_DIVORCIO on DATOS_DIVORCIO.ID_MATRI = FORMULARIO.ID_MATRI where CEDULA_PER = '" + txtbuscar.Text + "'", con);

                DataTable dt = new DataTable();
                //DataTable dt1 = new DataTable();

                da.Fill(dt);
                //da1.Fill(dt1);
                this.GridView1.DataSource = dt;
                //this.GridView2.DataSource = dt1;
                GridView1.DataBind();
                //GridView2.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}