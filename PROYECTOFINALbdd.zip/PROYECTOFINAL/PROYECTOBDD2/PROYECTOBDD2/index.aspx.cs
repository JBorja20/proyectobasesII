﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace PROYECTOBDD2
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=FORMULARIO;Integrated Security=True");
            string iddato_per = "";
            String cedula = "";
            SqlCommand cmd = new SqlCommand("select NOMBRE_FUNC_FORM , CEDULA_FUNC_FORM from FORMULARIO where NOMBRE_FUNC_FORM ='" + txtusuario.Text + "'and CEDULA_FUNC_FORM ='" + txtcontrasena.Text + "'", con);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            SqlDataReader leer;
            con.Open();
            leer = cmd.ExecuteReader();
            if (leer.Read() == true)
            {
                iddato_per = leer["NOMBRE_FUNC_FORM"].ToString();
                cedula = leer["CEDULA_FUNC_FORM"].ToString();
                Response.Redirect("/PAGINAS/formulario.aspx", true);

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Mensaje", "<script>alert('Datos incorrectos')</script>");
            }


            con.Close();


        }

        protected void btnVerFormulario_Click(object sender, EventArgs e)
        {
            Response.Redirect("/PAGINAS/datos.aspx", true);
        }
    }
}