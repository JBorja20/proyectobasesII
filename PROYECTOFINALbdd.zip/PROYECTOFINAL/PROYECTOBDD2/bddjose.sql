create database FORMULARIO
use FORMULARIO

create table AUTOIDENTIFICACION (
   ID_AUTOID            int          identity(1,1)        not null,
   ETNIA                char(35)             not null,
   constraint PK_AUTOIDENTIFICACION primary key (ID_AUTOID)
)
go

/*==============================================================*/
/* Table: DATOS_DIVORCIO                                        */
/*==============================================================*/
create table DATOS_DIVORCIO (
   ID_MATRI             bigint  identity(1,1)             not null,
   FECHA_MATRI          datetime             not null,
   BIENES               char(2)              not null,
   DURACION_MATRI       int                  not null,
   CAUSA                char(100)            not null,
   constraint PK_DATOS_DIVORCIO primary key (ID_MATRI)
)
go



/*==============================================================*/
/* Table: DATOS_PERSONALES                                      */
/*==============================================================*/

create table DATOS_PERSONALES (
   IDDARO_PER           bigint     identity(1,1)          not null,
   ID_UBI               bigint               null,
   ID_AUTOID            int                  null,
   ID_INST              int                  null,
   ID_NAC               bigint               null,
   NOMBRE_PER           char(20)             not null,
   APELLIDO_PER         char(35)             not null,
   CEDULA_PER           char(13)             not null,
   FECHA_NAC_PER        datetime             not null,
   EDAD                 int                  not null,
   HIJOS_CAR_PER        smallint             not null,
   GENERO_PER           char(11)             not null,
   DPA_PER              int                  not null,
   LOCAL_PER            int                  not null,
   constraint PK_DATOS_PERSONALES primary key (IDDARO_PER)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_4_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_4_FK on DATOS_PERSONALES (
ID_UBI ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_5_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_5_FK on DATOS_PERSONALES (
ID_AUTOID ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_6_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_6_FK on DATOS_PERSONALES (
ID_INST ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_7_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_7_FK on DATOS_PERSONALES (
ID_NAC ASC
)
go

/*==============================================================*/
/* Table: FORMULARIO                                            */
/*==============================================================*/
drop table FORMULARIO
create table FORMULARIO (
   ID_FORM              bigint identity(1,1)               not null,
   ID_MATRI             bigint               null,
   ID_UBI               bigint               null,
   IDDARO_PER           bigint               null,
   IDDARO_PER1			bigint				 null,
   OFICINA_FORM         char(20)             not null,
   FECHA_INSCRP         datetime             not null,
   NEC_FORM             varchar(6)           not null,
   NUM_OFIC_FORM        int                  not null,
   ACT_INSCIP_FORM      char(15)             not null,
   FECHA_SENT_FORM      datetime             not null,
   NOMBRE_FUNC_FORM     char(50)             not null,
   CEDULA_FUNC_FORM     char(13)             not null,
   OBSER_FORM           char(150)            not null,
   COD_CRIT_CODI        int                  not null,
   constraint PK_FORMULARIO primary key (ID_FORM)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_1_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_1_FK on FORMULARIO (
ID_MATRI ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_2_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_2_FK on FORMULARIO (
ID_UBI ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_3_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_3_FK on FORMULARIO (
IDDARO_PER ASC
)
go

/*==============================================================*/
/* Table: NACIONALIDAD                                          */
/*==============================================================*/

create table NACIONALIDAD (
   ID_NAC               bigint    identity(1,1)            not null,
   NACION               char(15)             not null,
   PAIS_NAC             char(30)             null,
   CODPAIS_NAC          bigint               null,
   constraint PK_NACIONALIDAD primary key (ID_NAC)
)
go

/*==============================================================*/
/* Table: NIVEL_INSTRUCCION                                     */
/*==============================================================*/

create table NIVEL_INSTRUCCION (
   ID_INST              int     identity(1,1)             not null,
   LEER_ESC_INST        char(2)              not null,
   NIVEL                char(30)             null,
   constraint PK_NIVEL_INSTRUCCION primary key (ID_INST)
)
go

/*==============================================================*/
/* Table: UBICACION                                             */
/*==============================================================*/

create table UBICACION (
   ID_UBI               bigint    identity(1,1 )           not null,
   PROVINCIA            char(40)             not null,
   CANTON               char(40)             not null,
   PARROQUIA            char(40)             not null,
   LOCALIDAD            char(40)             null,
   constraint PK_UBICACION primary key (ID_UBI)
)
go

alter table DATOS_PERSONALES
   add constraint FK_DATOS_PE_RELATIONS_UBICACIO foreign key (ID_UBI)
      references UBICACION (ID_UBI)
go

alter table DATOS_PERSONALES
   add constraint FK_DATOS_PE_RELATIONS_AUTOIDEN foreign key (ID_AUTOID)
      references AUTOIDENTIFICACION (ID_AUTOID)
go

alter table DATOS_PERSONALES
   add constraint FK_DATOS_PE_RELATIONS_NIVEL_IN foreign key (ID_INST)
      references NIVEL_INSTRUCCION (ID_INST)
go

alter table DATOS_PERSONALES
   add constraint FK_DATOS_PE_RELATIONS_NACIONAL foreign key (ID_NAC)
      references NACIONALIDAD (ID_NAC)
go

alter table FORMULARIO
   add constraint FK_FORMULAR_RELATIONS_DATOS_DI foreign key (ID_MATRI)
      references DATOS_DIVORCIO (ID_MATRI)
go

alter table FORMULARIO
   add constraint FK_FORMULAR_RELATIONS_UBICACIO foreign key (ID_UBI)
      references UBICACION (ID_UBI)
go

alter table FORMULARIO
   add constraint FK_FORMULAR_RELATIONS_DATOS_PE foreign key (IDDARO_PER)
      references DATOS_PERSONALES (IDDARO_PER)
   
go

alter table FORMULARIO
	add constraint FK_FORMULAR_RELATIONS_DATOS_PE1 foreign key (IDDARO_PER1)
      references DATOS_PERSONALES (IDDARO_PER) 

create table AUDITORIA(
id int identity(1, 1) not null,
fecha datetime not null,
nombre varchar(30) not null
)

