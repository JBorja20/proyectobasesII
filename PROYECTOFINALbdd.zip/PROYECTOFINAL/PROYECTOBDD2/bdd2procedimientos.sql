CREATE proc INSERTAR_NIVEL
@ID_Inst int,
@Leer varchar(30),
@Nivel varchar(30)
as
insert into NIVEL_INSTRUCCION (ID_INST, LEER_ESC_INST, NIVEL) values(@ID_Inst, @Leer, @Nivel)


CREATE proc INSERTAR_DATO_DIVORCIO
@FechaMatri  date,
@bienes char(2),
@Duracion_Matri int,
@causa char(100)
as
insert into DATOS_DIVORCIO(FECHA_MATRI, BIENES, DURACION_MATRI, CAUSA) values(@FechaMatri, @bienes, @Duracion_Matri, @causa)


ALTER procedure INSERTAR_UBICACION_FORMULARIO
@PROVINCIA char(40),
@CANTON char(40),
@PARROQUIA char(40),
@LOCALIDAD char(40)
as
insert into UBICACION(PROVINCIA, CANTON, PARROQUIA, LOCALIDAD) values(@PROVINCIA, @CANTON, @PARROQUIA, @LOCALIDAD)

create procedure INSERTAR_UBICACION_DIVORCIADO
@PROVINCIA char(40),
@CANTON char(40),
@PARROQUIA char(40),
@LOCALIDAD char(40)
as
insert into UBICACION(PROVINCIA, CANTON, PARROQUIA, LOCALIDAD) values(@PROVINCIA, @CANTON, @PARROQUIA, @LOCALIDAD)

create procedure INSERTAR_UBICACION_DIVORCIADA
@PROVINCIA char(40),
@CANTON char(40),
@PARROQUIA char(40),
@LOCALIDAD char(40)
as
insert into UBICACION(PROVINCIA, CANTON, PARROQUIA, LOCALIDAD) values(@PROVINCIA, @CANTON, @PARROQUIA, @LOCALIDAD)

create procedure INSERTAR_NACIONALIDAD_DIVORCIADO
@Nacion char(15),
@Pais_nac char(30),
@codpaid_nac bigint
as
insert into NACIONALIDAD(NACION, PAIS_NAC, CODPAIS_NAC) values(@Nacion, @Pais_nac, @codpaid_nac)

create procedure INSERTAR_NACIONALIDAD_DIVORCIADA
@Nacion char(15),
@Pais_nac char(30),
@codpaid_nac bigint
as
insert into NACIONALIDAD(NACION, PAIS_NAC, CODPAIS_NAC) values(@Nacion, @Pais_nac, @codpaid_nac)

create procedure INSERTAR_ETNIA_DIVORCIADO
@etnia char(35)
as
insert into AUTOIDENTIFICACION(ETNIA) values(@etnia)

create procedure INSERTAR_ETNIA_DIVORCIADA
@etnia char(35)
as
insert into AUTOIDENTIFICACION(ETNIA) values(@etnia)

create procedure INSERTAR_NIVEL_INSTRUCCION_DIVORCIADA
@leer_esc char(2),
@nivel char(30)
as
insert into NIVEL_INSTRUCCION(LEER_ESC_INST, NIVEL) values(@leer_esc, @nivel)

create procedure INSERTAR_NIVEL_INSTRUCCION_DIVORCIADA
@leer_esc char(2),
@nivel char(30)
as
insert into NIVEL_INSTRUCCION(LEER_ESC_INST, NIVEL) values(@leer_esc, @nivel)

create procedure INSERTAR_DATOS_PERSONALES_DIVORCIADO
@id_ubi int,
@id_autoID int,
@id_inst int,
@id_nac int,
@nombre_per char(20),
@apellido char(35),
@cedula char(13),
@fecha date,
@edad int,
@hijos int,
@genero char(11),
@DPA_PER int,
@LOCAL_PER int
as
insert into DATOS_PERSONALES(ID_UBI, ID_AUTOID, ID_INST, ID_NAC, NOMBRE_PER, APELLIDO_PER, CEDULA_PER, FECHA_NAC_PER, EDAD, HIJOS_CAR_PER, GENERO_PER, DPA_PER, LOCAL_PER) values(@id_ubi, @id_autoID, @id_inst, @id_nac, @nombre_per, @apellido, @cedula, @fecha, @edad, @hijos, @genero, @DPA_PER, @LOCAL_PER)

create procedure INSERTAR_DATOS_PERSONALES_DIVORCIADA
@id_ubi int,
@id_autoID int,
@id_inst int,
@id_nac int,
@nombre_per char(20),
@apellido char(35),
@cedula char(13),
@fecha date,
@edad int,
@hijos int,
@genero char(11),
@DPA_PER int,
@LOCAL_PER int
as
insert into DATOS_PERSONALES(ID_UBI, ID_AUTOID, ID_INST, ID_NAC, NOMBRE_PER, APELLIDO_PER, CEDULA_PER, FECHA_NAC_PER, EDAD, HIJOS_CAR_PER, GENERO_PER, DPA_PER, LOCAL_PER) values(@id_ubi, @id_autoID, @id_inst, @id_nac, @nombre_per, @apellido, @cedula, @fecha, @edad, @hijos, @genero, @DPA_PER, @LOCAL_PER)

create procedure INSERTAR_FORMULARIO
@id_matri bigint,
@id_ubi bigint,
@iddaro_per bigint,
@iddaro_per1 bigint,
@oficina_form char(20),
@fecha_inscrp datetime,
@nec_form varchar(6),
@num_ofic_form int,
@act_inscip_form char(15),
@fecha_sent_form datetime,
@nombre_func_form char(50),
@cedula_func_form char(13),
@obser_form char(150),
@cod_crit_codi int
as
insert into FORMULARIO(ID_MATRI ,ID_UBI, IDDARO_PER, IDDARO_PER1, OFICINA_FORM, FECHA_INSCRP, NEC_FORM, NUM_OFIC_FORM, 
ACT_INSCIP_FORM, FECHA_SENT_FORM, NOMBRE_FUNC_FORM, CEDULA_FUNC_FORM, OBSER_FORM, COD_CRIT_CODI)

values(@id_matri, @id_ubi, @iddaro_per, @iddaro_per1, @oficina_form, @fecha_inscrp, @nec_form, @num_ofic_form, 
@act_inscip_form, @fecha_sent_form, @nombre_func_form, @cedula_func_form, @obser_form, @cod_crit_codi)



create trigger AUDITORIAS on FORMULARIO
for insert
as
begin
	insert into AUDITORIA(fecha, nombre) 
	select getdate(), INSERTED.NOMBRE_FUNC_FORM from INSERTED
end

